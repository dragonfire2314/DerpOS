//command.c
void help();
void hex(char *addr);
void loadHex();
int pow(int base, int power);
void run(char *addr);
void settings();

extern char BG_COLOR;
extern char FG_COLOR;
extern char BOARDER_COLOR;

//gdt.c
void gdt_init();

//Screen.c
void putc(char letter, int x, int y, unsigned short color);
void puts(char *str, int x, int y, unsigned short color);
void cls(unsigned short color);
unsigned short MakeColor(unsigned char bg, unsigned char fg);

//Renderer.c
void RenderScreenKernel();
void keyCheck();
int commandCheck();
void boarder(char *string, int length);
void CommandLinePutc(char str, int x, int y);
void cursormove(int row, int col);

extern char *text;
extern char list[4][16];
extern int cursorX;
extern int cursorY;
extern int commandCount;

//io.c
char* textBankAdress();

void idt_init(void);
void kb_init(void);
void keyboard_handler_main(void);
//bool keypress

//interrupts.c


//kernel.c
extern char current_program_ID;

//drive.c
void drive();

//coltynGame.c
void ColtynMain();
