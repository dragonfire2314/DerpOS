#include "system.h"

extern char read_port(unsigned short port);
extern void write_port(unsigned short port, unsigned char data);

char *sector = (char*)0x200000;

void drive()
{
    unsigned char c;
    write_port(0x70, 0x10);
    c = read_port(0x71);

    unsigned char a = c >> 4;
    unsigned char b = c & 0xF;

    char *drive_type[6] = { "no floppy drive", "360kb 5.25in floppy drive", "1.2mb 5.25in floppy drive", "720kb 3.5in", "1.44mb 3.5in", "2.88mb 3.5in"};
    puts("Floppy drive A is an:", 1, 9, 0x0F);
    puts(drive_type[a], 1, 10, 0x0F);
    puts("Floppy drive B is an:", 1, 11, 0x0F);
    puts(drive_type[b], 1, 12, 0x0F);

    unsigned int g = 0x200000;

    write_port(0x1F1, 0x00);
    write_port(0x1F2, 0x00);

    write_port(0x1F3, (unsigned char)g);
    write_port(0x1F4, (unsigned char)g >> 8);
    write_port(0x1F5, (unsigned char)g >> 16);
    write_port(0x1F6, 0xE0 | (0x00 << 4) | (g >> 24) & 0x0F);

    write_port(0x1F7, 0x20);

    while(!(read_port(0x1F7) & 0x08)){}

    for(int idx = 0; idx < 256; idx++)
    {
        int tempword = read_port(0x1F0);
        sector[idx * 2] = (unsigned char)tempword;
        sector[idx * 2  + 1] = (unsigned char)(tempword >> 8);
    }

}