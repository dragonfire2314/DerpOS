/*
	DerpOS Kernel V 0.28
	By Tanner Kern, Coltyn Sheland
*/
#include "system.h"
#include "programs.h"
//Function definitions


//Externs
extern int test(void);
extern unsigned char Sample[524288];

//Definitions
#define SCREENSIZE 4000 // 80 * 25 * 2

//Variables
char *ScreenLoc = (char*)0xb8000;

char *ss = (char*)0x01000000;

char current_program_ID = 0; 

void kmain(void)
{
	//gdt_init();

	char *_test = "Rino";

	//Clears the screen
	cls(0x80);
	puts(_test, 3, 20, 0x34);
	
	idt_init();
	kb_init();

	//drive();

	for(int i = 0; i < 524288; i++)
	{
		ss[i] = Sample[i];
	}

	//ss[0] = 'v';
	//ss[1] = 0x03;
	//ss[2] = 0x03;
	//ss[4] = 0x45;

	//putc(*ss, 0x04, 0x04, 0x34);

	//test();

	while(1)
	{
		RenderScreenKernel();
	}

	return;
}