#include "system.h"

#define PROGRAMS_START 0x01000000

//INT 34 - Might cause an error due to the int d being an integer
void put_pixel_main()
{
    int d = (current_program_ID * PROGRAMS_START);
    char *OFFSET = (char*)PROGRAMS_START;
    char c = OFFSET[0 + d];
    unsigned char x = OFFSET[1 + d];
    unsigned char y = OFFSET[2 + d];
    unsigned char color = OFFSET[3 + d];
    putc(c, x, y, color);
}