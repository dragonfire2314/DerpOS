#include "system.h"

/*
        AVALIBLE FUNCTIONS
----------------------------------------------------------------------
void putc(char letter, int x, int y, unsigned short color);
void puts(char *str, int x, int y, unsigned short color);
void cls(unsigned short color);
unsigned short MakeColor(unsigned char bg, unsigned char fg);

void boarder(char *string, int length);

        KEYBOARD
----------------------------------------------------------------------
For keyboard input
    //This is when enter is pressed
    if(text[0] == 2){}


    //All other keys
    else if(text[0] == 3)
    {
        Keyboard Input is in here  ----->  text[1]
    }
    text[0] = 0;

Set text[0] = 0 after the keypress has been accepted
*/

/*
        TO RUN THE PROGRAM
----------------------------------------------------------------------
        1.Compile.bat
        2.Run.bat
        3.Enter "run coltyn" in the command line
        4.Profit
*/

void ColtynMain()
{
    //Test line to see if it works
    CommandLinePutc('5', 5, 5);
}